Os oficiais do rei responderam: "É Hamã que está no pátio".
"Façam-no entrar", ordenou o rei.