"Que honra e reconhecimento Mardoqueu recebeu por isso?", perguntou o rei.
Seus oficiais responderam: "Nada lhe foi feito".