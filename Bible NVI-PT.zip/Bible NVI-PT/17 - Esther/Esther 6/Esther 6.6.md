Entrando Hamã, o rei lhe perguntou: "O que se deve fazer ao homem que o rei tem o prazer de honrar?"
E Hamã pensou consigo: "A quem o rei teria prazer de honrar, senão a mim?"