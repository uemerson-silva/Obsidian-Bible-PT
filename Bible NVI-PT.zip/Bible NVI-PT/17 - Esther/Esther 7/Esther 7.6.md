Respondeu Ester: "O adversário e inimigo é Hamã, esse perverso".
Diante disso, Hamã ficou apavorado na presença do rei e da rainha.