Disse o rei: "Tragam Hamã imediatamente, para que ele atenda ao pedido de Ester".
Então o rei e Hamã foram ao banquete que Ester havia preparado.