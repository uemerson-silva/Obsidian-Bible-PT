Hamã, porém, controlou-se e foi para casa.
Reunindo seus amigos e Zeres, sua mulher,