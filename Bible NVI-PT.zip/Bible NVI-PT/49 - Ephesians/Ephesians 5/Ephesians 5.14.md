Por isso é que foi dito:
"Desperta, ó tu que dormes,  
    levanta-te dentre os mortos  
e Cristo resplandecerá  
    sobre ti".Vida em Comunidade