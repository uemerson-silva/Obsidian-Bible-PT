Paulo, apóstolo de Cristo Jesus pela vontade de Deus,
aos santos e fiéis em Cristo Jesus que estão em Éfeso: