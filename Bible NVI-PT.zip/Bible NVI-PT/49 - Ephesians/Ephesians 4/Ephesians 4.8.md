Por isso é que foi dito:
"Quando ele subiu em triunfo às alturas,  
    levou cativos muitos prisioneiros,  
e deu dons aos homens".