Da mesma forma, Cristo não tomou para si a glória de se tornar sumo sacerdote, mas Deus lhe disse:
"Tu és meu Filho;  
    eu hoje te gerei".