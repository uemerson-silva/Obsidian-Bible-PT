E diz noutro lugar:
"Tu és sacerdote para sempre,  
segundo a ordem  
    de Melquisedeque".