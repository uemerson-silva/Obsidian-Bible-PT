pois o Senhor disciplina  
    a quem ama,  
e castiga todo aquele  
    a quem aceita como filho".