Vocês se esqueceram da palavra de ânimo que ele lhes dirige como a filhos:
"Meu filho, não despreze  
    a disciplina do Senhor,  
nem se magoe  
    com a sua repreensão,