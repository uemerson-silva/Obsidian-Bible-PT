Por isso é que se diz:
"Se hoje vocês ouvirem  
    a sua voz,  
não endureçam o coração,  
    como na rebelião".