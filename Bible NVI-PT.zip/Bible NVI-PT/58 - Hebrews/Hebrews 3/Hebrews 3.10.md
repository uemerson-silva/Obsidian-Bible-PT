Por isso fiquei irado  
    contra aquela geração  
e disse: O seu coração  
    está sempre se desviando,  
e eles não reconheceram  
    os meus caminhos.