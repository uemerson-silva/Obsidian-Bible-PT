não endureçam o coração,  
    como na rebelião,  
durante o tempo da provação no deserto,