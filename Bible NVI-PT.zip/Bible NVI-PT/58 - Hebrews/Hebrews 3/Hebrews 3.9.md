onde os seus antepassados  
    me tentaram,  
    pondo-me à prova,  
apesar de, durante quarenta anos,  
    terem visto o que eu fiz.