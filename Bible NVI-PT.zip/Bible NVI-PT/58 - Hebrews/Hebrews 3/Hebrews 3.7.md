Assim, como diz o Espírito Santo:
"Hoje, se vocês ouvirem  
    a sua voz,