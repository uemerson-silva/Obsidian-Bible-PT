Assim jurei na minha ira:  
Jamais entrarão  
    no meu descanso".