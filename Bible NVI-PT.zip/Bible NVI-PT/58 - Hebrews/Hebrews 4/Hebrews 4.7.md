Por isso Deus estabelece outra vez um determinado dia, chamando-o "hoje", ao declarar muito tempo depois, por meio de Davi, de acordo com o que fora dito antes:
"Se hoje vocês ouvirem  
    a sua voz,  
não endureçam o coração".