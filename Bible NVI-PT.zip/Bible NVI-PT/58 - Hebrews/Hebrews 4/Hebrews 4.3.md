Pois nós, os que cremos, é que entramos naquele descanso, conforme Deus disse:
"Assim jurei na minha ira:  
Jamais entrarão  
    no meu descanso";
embora as suas obras estivessem concluídas desde a criação do mundo.