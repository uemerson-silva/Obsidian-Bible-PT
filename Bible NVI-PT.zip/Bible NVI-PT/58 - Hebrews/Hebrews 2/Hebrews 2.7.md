Tu o fizeste um pouco menor  
    do que os anjos  
e o coroaste de glória e de honra;