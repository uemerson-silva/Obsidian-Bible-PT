tudo sujeitaste debaixo  
    dos seus pés".
Ao lhe sujeitar todas as coisas, nada deixou que não lhe estivesse sujeito. Agora, porém, ainda não vemos que todas as coisas lhe estejam sujeitas.