mas alguém em certo lugar testemunhou, dizendo:
"Que é o homem, para que  
    com ele te importes?  
E o filho do homem,  
    para que com ele te preocupes?