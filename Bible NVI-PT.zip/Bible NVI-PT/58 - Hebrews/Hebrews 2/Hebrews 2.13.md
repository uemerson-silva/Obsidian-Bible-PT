E também:
"Nele porei  
    a minha confiança".
Novamente ele diz:
"Aqui estou eu com os filhos  
    que Deus me deu".