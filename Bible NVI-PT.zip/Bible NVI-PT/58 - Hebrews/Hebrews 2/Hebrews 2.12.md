Ele diz:
"Proclamarei o teu nome  
    a meus irmãos;  
na assembléia te louvarei".