Então eu disse:  
    Aqui estou,  
no livro está escrito  
    a meu respeito;  
vim para fazer a tua vontade, ó Deus".