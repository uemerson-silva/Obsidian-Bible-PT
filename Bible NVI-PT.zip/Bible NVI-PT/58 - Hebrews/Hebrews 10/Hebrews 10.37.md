pois em breve, muito em breve
"Aquele que vem virá,  
    e não demorará.