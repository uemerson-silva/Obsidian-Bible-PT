e acrescenta:
"Dos seus pecados  
    e iniqüidades  
não me lembrarei mais".