de holocaustos e ofertas  
    pelo pecado  
não te agradaste.