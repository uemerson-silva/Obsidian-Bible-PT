"Esta é a aliança que farei com eles,  
depois daqueles dias,  
    diz o Senhor.  
Porei as minhas leis  
    em seu coração  
e as escreverei  
    em sua mente";