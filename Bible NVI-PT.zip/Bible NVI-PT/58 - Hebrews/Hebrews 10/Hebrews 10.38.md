Mas o meu justo  
    viverá pela fé.  
E, se retroceder,  
    não me agradarei dele".