Podemos, pois, dizer com confiança:
"O Senhor é o meu ajudador,  
    não temerei.  
O que me podem fazer  
    os homens?"