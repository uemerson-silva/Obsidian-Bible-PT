Conservem-se livres do amor ao dinheiro e contentem-se com o que vocês têm, porque Deus mesmo disse:
"Nunca o deixarei,  
nunca o abandonarei".